<?php
class CrugeMailerException extends Exception
{

}
